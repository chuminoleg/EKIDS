package Kotlin.GlebProject.LostPlanet

class game {

    fun main() {

        // написать комментарий к каждой функции и какие переменные она будет принимать и какой результат выдавать
        fun guns() {

        }

        fun enemy() {

        }

        fun base() {

        }

        fun feald() {

        }

        fun projectale() {

        }

        fun boss() {

        }

        fun lvls() {

        }
    }

}